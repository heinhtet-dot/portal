from django.shortcuts import render
from .models import Post
from django.http.response import HttpResponse, HttpResponseRedirect
from django.db.models import Q 
from django.contrib.auth.models import User
from django.contrib import messages




def index(request):
    return render(request, 'website/index.html')
    
def home(request):
    context = {
        'posts': Post.objects.all()
    }
    return render(request, 'website/home.html', context)


def about(request):
    return render(request, 'website/about.html', {'title': 'About'})

def search(request):
    
    if request.method== 'POST':
        srch = request.POST['srh']
        
        if srch:
            
            match = User.objects.filter(Q(username__icontains =srch))
            if match:
                return render(request,'website/search.html', {'sr':match})
            else:
                messages.error(request,'No Result Found')
        else:
            return HttpResponseRedirect('website/search.html')
        
    return render(request,'website/search.html')