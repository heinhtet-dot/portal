from django.urls import path
from . import views
from django.conf.urls import url
from .views import (search)
urlpatterns = [
    path('', views.index, name='web-index'),
    path('home/', views.home, name='web-home'),
    path('about/', views.about, name='web-about'),
    url(r'^search/$',views.search,name='search'),
    ]